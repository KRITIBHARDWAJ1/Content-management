import IconFrame from "../components/icon-frame";
import Project from "../components/project";
import Article1 from "../components/article1";
import Story from "../components/story";
import FrameComponent from "../components/frame-component";
import styles from "./index.module.css";

const ContentManagement = () => {
  return (
    <div className={styles.contentManagement}>
      <div className={styles.frameGroup}>
        <main className={styles.textRectangle}>
          <div className={styles.sidebar}>
            <div className={styles.chevronSep}>
              <div className={styles.businessFrame}>
                <div className={styles.languageGroup}>
                  <input className={styles.home2} type="checkbox" />
                  <div className={styles.dashboard}>Dashboard</div>
                </div>
              </div>
              <button className={styles.active}>
                <img
                  className={styles.documentTextIcon}
                  alt=""
                  src="/documenttext.svg"
                />
                <div className={styles.content}>Content</div>
              </button>
              <div className={styles.businessFrame1}>
                <div className={styles.profile2userParent}>
                  <img
                    className={styles.profile2userIcon}
                    loading="eager"
                    alt=""
                    src="/profile2user.svg"
                  />
                  <div className={styles.team}>Team</div>
                </div>
              </div>
              <div className={styles.businessFrame2}>
                <div className={styles.userSquareParent}>
                  <img
                    className={styles.userSquareIcon}
                    loading="eager"
                    alt=""
                    src="/usersquare.svg"
                  />
                  <div className={styles.user}>User</div>
                </div>
              </div>
              <div className={styles.businessFrame3}>
                <div className={styles.monitorMobbileParent}>
                  <img
                    className={styles.monitorMobbileIcon}
                    loading="eager"
                    alt=""
                    src="/monitormobbile.svg"
                  />
                  <div className={styles.appweb}>App/Web</div>
                </div>
              </div>
              <div className={styles.restaurantFrame}>
                <IconFrame />
              </div>
            </div>
            <div className={styles.logout}>
              <img
                className={styles.fiheadphonesIcon}
                alt=""
                src="/fiheadphones.svg"
              />
              <div className={styles.contactSupport}>Contact Support</div>
            </div>
          </div>
          <section className={styles.contentCParent}>
            <header className={styles.contentC}>
              <div className={styles.rectangleParent}>
                <div className={styles.frameChild} />
                <img
                  className={styles.akarIconssearch}
                  alt=""
                  src="/akariconssearch.svg"
                />
                <input
                  className={styles.search}
                  placeholder="Search"
                  type="text"
                />
              </div>
              <div className={styles.frameParent}>
                <div className={styles.rectangleGroup}>
                  <div className={styles.frameItem} />
                  <div className={styles.parent}>
                    <div className={styles.div}>11-10-2022</div>
                    <img
                      className={styles.calendarIcon}
                      alt=""
                      src="/calendar.svg"
                    />
                  </div>
                  <div className={styles.or}>OR</div>
                  <div className={styles.group}>
                    <div className={styles.div1}>11-10-2022</div>
                    <img
                      className={styles.calendarIcon1}
                      alt=""
                      src="/calendar.svg"
                    />
                  </div>
                </div>
                <div className={styles.groupM}>
                  <div className={styles.dividerN}>
                    <img
                      className={styles.image11Icon}
                      alt=""
                      src="/image-11@2x.png"
                    />
                    <div className={styles.itemP}>
                      <div className={styles.welcomeBack}>Welcome back,</div>
                      <div className={styles.akshitaPatel}>Akshita Patel</div>
                    </div>
                    <img
                      className={styles.arrowDown2}
                      alt=""
                      src="/arrow--down-2.svg"
                    />
                  </div>
                </div>
              </div>
            </header>
            <div className={styles.frameWrapper}>
              <div className={styles.frameLanguageParent}>
                <div className={styles.frameLanguage}>
                  <div className={styles.businessBlock}>
                    <h1 className={styles.helloAdmin}>Hello Admin,</h1>
                    <div className={styles.thisIsWhat}>
                      This is what we got you for today.
                    </div>
                  </div>
                  <div className={styles.callToAction}>
                    <Project
                      projectIcon="/project-icon.svg"
                      articles="Articles"
                      newUpdates="4,950 New Updates"
                    />
                    <div className={styles.notification}>
                      <img
                        className={styles.notificatonIcon}
                        loading="eager"
                        alt=""
                        src="/notificaton-icon.svg"
                      />
                      <div className={styles.categoriesParent}>
                        <div className={styles.categories}>Categories</div>
                        <div className={styles.newUpdates}>
                          10,275 New Updates
                        </div>
                      </div>
                    </div>
                    <Project
                      projectIcon="/client-icon.svg"
                      articles="Stories"
                      newUpdates="4,193 New Updates"
                      propColor="#22285e"
                      propColor1="#22285e"
                    />
                    <div className={styles.client}>
                      <img
                        className={styles.clientIcon}
                        alt=""
                        src="/client-icon-1.svg"
                      />
                      <div className={styles.advertisementsParent}>
                        <h2 className={styles.advertisements}>
                          Advertisements
                        </h2>
                        <div className={styles.newUpdates1}>
                          928 New Updates
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles.libreCoffeeKFC}>
                  <h3 className={styles.topArticles}>Top Articles</h3>
                  <div className={styles.seeAll}>See all</div>
                </div>
                <div className={styles.chevron}>
                  <div className={styles.article}>
                    <div className={styles.article1}>
                      <img
                        className={styles.article1Child}
                        alt=""
                        src="/frame-1000001069@2x.png"
                      />
                      <div className={styles.business}>BUSINESS</div>
                      <div className={styles.rulesOfEffective}>
                        7 Rules of Effective Branding
                      </div>
                      <div className={styles.whyBrandingMatters}>
                        Why Branding matters for your Business
                      </div>
                      <div className={styles.publishedWrapper}>
                        <div className={styles.published}>Published</div>
                      </div>
                      <div className={styles.brandingWrapper}>
                        <div className={styles.branding}>Branding</div>
                      </div>
                      <div className={styles.communicationWrapper}>
                        <div className={styles.communication}>
                          Communication
                        </div>
                      </div>
                      <div className={styles.brandingContainer}>
                        <div className={styles.branding1}>Branding</div>
                      </div>
                      <div className={styles.mariaDoe}>Maria Doe</div>
                      <img
                        className={styles.article1Item}
                        alt=""
                        src="/ellipse-2@2x.png"
                      />
                      <div className={styles.sep2022}>20 Sep 2022</div>
                      <div className={styles.rectangleContainer}>
                        <div className={styles.frameInner} />
                        <div className={styles.view}>{`View `}</div>
                      </div>
                      <div className={styles.article1Inner} />
                    </div>
                    <div className={styles.article2}>
                      <div className={styles.frameDiv}>
                        <img
                          className={styles.rectangleIcon}
                          alt=""
                          src="/rectangle-684@2x.png"
                        />
                        <img
                          className={styles.frameChild1}
                          alt=""
                          src="/rectangle-685@2x.png"
                        />
                      </div>
                      <div className={styles.economy}>ECONOMY</div>
                      <div className={styles.researchOnBiodiversity}>
                        Research on biodiversity an...
                      </div>
                      <div className={styles.loremIpsumDolor}>
                        Lorem ipsum dolor sit amet, consectetur
                      </div>
                      <div className={styles.publishedContainer}>
                        <div className={styles.published1}>Published</div>
                      </div>
                      <div className={styles.worldWrapper}>
                        <div className={styles.world}>World</div>
                      </div>
                      <div className={styles.populationWrapper}>
                        <div className={styles.population}>Population</div>
                      </div>
                      <div className={styles.mariaDoe1}>Maria Doe</div>
                      <img
                        className={styles.article2Child}
                        alt=""
                        src="/ellipse-2@2x.png"
                      />
                      <div className={styles.sep20221}>20 Sep 2022</div>
                      <div className={styles.groupDiv}>
                        <div className={styles.rectangleDiv} />
                        <div className={styles.view1}>{`View `}</div>
                      </div>
                      <div className={styles.article2Item} />
                    </div>
                    <div className={styles.article21}>
                      <div className={styles.rectangleParent1}>
                        <img
                          className={styles.frameChild2}
                          alt=""
                          src="/rectangle-684@2x.png"
                        />
                        <img
                          className={styles.frameChild3}
                          alt=""
                          src="/rectangle-685-1@2x.png"
                        />
                      </div>
                      <div className={styles.politics}>POLITICS</div>
                      <div className={styles.closeAndHistorical}>
                        Close and historical ties to h...
                      </div>
                      <div className={styles.loremIpsumDolor1}>
                        Lorem ipsum dolor sit amet, consectetur
                      </div>
                      <div className={styles.publishedFrame}>
                        <div className={styles.published2}>Published</div>
                      </div>
                      <div className={styles.politicsWrapper}>
                        <div className={styles.politics1}>Politics</div>
                      </div>
                      <div className={styles.defenceWrapper}>
                        <div className={styles.defence}>Defence</div>
                      </div>
                      <div className={styles.mariaDoe2}>Maria Doe</div>
                      <img
                        className={styles.article2Inner}
                        alt=""
                        src="/ellipse-2@2x.png"
                      />
                      <div className={styles.sep20222}>20 Sep 2022</div>
                      <div className={styles.rectangleParent2}>
                        <div className={styles.frameChild4} />
                        <div className={styles.view2}>{`View `}</div>
                      </div>
                      <div className={styles.ellipseDiv} />
                    </div>
                    <div className={styles.article11}>
                      <img
                        className={styles.frameGroupIcon}
                        alt=""
                        src="/frame-1000001069@2x.png"
                      />
                      <div className={styles.lineGroup}>
                        <div className={styles.pathShape}>
                          <div className={styles.parentBox}>
                            <div className={styles.rectangleGroup1}>
                              <div className={styles.business1}>BUSINESS</div>
                              <div className={styles.separatorLine}>
                                <div className={styles.frameWithText} />
                              </div>
                              <div className={styles.sep20223}>20 Sep 2022</div>
                            </div>
                            <div className={styles.groupWithViewParent}>
                              <img
                                className={styles.groupWithView}
                                alt=""
                                src="/ellipse-2@2x.png"
                              />
                              <div className={styles.mariaDoe3}>Maria Doe</div>
                            </div>
                          </div>
                          <div className={styles.horizontalLine}>
                            <div className={styles.dottedFrame}>
                              <h3 className={styles.rulesOfEffective1}>
                                7 Rules of Effective Branding
                              </h3>
                              <button className={styles.textEllipse}>
                                <div className={styles.created}>Created</div>
                              </button>
                            </div>
                            <div className={styles.whyBrandingMatters1}>
                              Why Branding matters for your Business
                            </div>
                          </div>
                        </div>
                        <div className={styles.lineWithTextParent}>
                          <button className={styles.lineWithText}>
                            <div className={styles.branding2}>Branding</div>
                          </button>
                          <button className={styles.rectangle}>
                            <div className={styles.communication1}>
                              Communication
                            </div>
                          </button>
                          <button className={styles.chezPierreLogo}>
                            <div className={styles.branding3}>Branding</div>
                          </button>
                        </div>
                      </div>
                      <div className={styles.sepFrameB}>
                        <div className={styles.sepFrameC}>
                          <button className={styles.groupButton}>
                            <div className={styles.frameChild5} />
                            <div className={styles.view3}>{`View `}</div>
                          </button>
                          <div className={styles.language4}>
                            <img
                              className={styles.language4Child}
                              alt=""
                              src="/group-1000000956.svg"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <Article1
                      textGroup="/rectangle-685@2x.png"
                      eCONOMY="ECONOMY"
                      researchOnBiodiversityAn="Research on biodiversity an..."
                      world="World"
                      population="Population"
                    />
                    <Article1
                      textGroup="/rectangle-685-1@2x.png"
                      eCONOMY="POLITICS"
                      researchOnBiodiversityAn="Close and historical ties to h..."
                      world="Politics"
                      population="Defence"
                      propPadding="0px var(--padding-8xs) var(--padding-8xs) 0px"
                      propGap="14px"
                      propWidth="199px"
                      propWidth1="88px"
                    />
                    <div className={styles.article22}>
                      <img
                        className={styles.frameIcon}
                        alt=""
                        src="/frame-1000001069@2x.png"
                      />
                      <div className={styles.frameContainer}>
                        <div className={styles.ellipseParent}>
                          <img
                            className={styles.ellipseIcon}
                            alt=""
                            src="/ellipse-2@2x.png"
                          />
                          <div className={styles.frameParent1}>
                            <div className={styles.businessParent}>
                              <div className={styles.business2}>BUSINESS</div>
                              <div className={styles.sep20224}>20 Sep 2022</div>
                            </div>
                            <div className={styles.mariaDoe4}>Maria Doe</div>
                          </div>
                          <div className={styles.frameChild6} />
                        </div>
                        <div className={styles.frameParent2}>
                          <div className={styles.frameParent3}>
                            <div
                              className={styles.rulesOfEffectiveBrandingParent}
                            >
                              <h3 className={styles.rulesOfEffective2}>
                                7 Rules of Effective Branding
                              </h3>
                              <div className={styles.whyBrandingMatters2}>
                                Why Branding matters for your Business
                              </div>
                            </div>
                            <div className={styles.parentShape}>
                              <div className={styles.published3}>Published</div>
                            </div>
                          </div>
                          <div className={styles.frameParent4}>
                            <div className={styles.brandingFrame}>
                              <div className={styles.branding4}>Branding</div>
                            </div>
                            <div className={styles.communicationContainer}>
                              <div className={styles.communication2}>
                                Communication
                              </div>
                            </div>
                            <div className={styles.ellipse}>
                              <div className={styles.branding5}>Branding</div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.politicsFrame}>
                          <div className={styles.politicsFrameChild} />
                          <div className={styles.view4}>{`View `}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles.libreCoffeeKFC1}>
                  <h3 className={styles.topStories}>Top Stories</h3>
                  <div className={styles.seeAll1}>See all</div>
                </div>
                <div className={styles.story}>
                  <div className={styles.story1}>
                    <div className={styles.story2}>
                      <img
                        className={styles.storyChild}
                        alt=""
                        src="/rectangle-685-4@2x.png"
                      />
                      <div className={styles.rectangleParent3}>
                        <div className={styles.frameChild7} />
                        <div className={styles.view5}>{`View `}</div>
                      </div>
                      <div className={styles.how7LinesContainer}>
                        <p className={styles.how7Lines}>
                          How 7 lines code turned into
                        </p>
                        <p className={styles.billionEmpire}>
                          $36 Billion Empire
                        </p>
                      </div>
                      <div className={styles.business3}>BUSINESS</div>
                      <div className={styles.sep20225}>20 Sep 2022</div>
                      <div className={styles.storyItem} />
                      <div className={styles.publishedWrapper1}>
                        <div className={styles.published4}>Published</div>
                      </div>
                      <div className={styles.icbaselineRemoveRedEyeParent}>
                        <img
                          className={styles.icbaselineRemoveRedEyeIcon}
                          alt=""
                          src="/icbaselineremoveredeye.svg"
                        />
                        <div className={styles.div2}>428</div>
                      </div>
                      <div className={styles.statusUpWrapper}>
                        <img
                          className={styles.statusUpIcon}
                          alt=""
                          src="/statusup-1.svg"
                        />
                      </div>
                    </div>
                    <div className={styles.story3}>
                      <img
                        className={styles.storyInner}
                        alt=""
                        src="/rectangle-685-5@2x.png"
                      />
                      <div className={styles.rectangleParent4}>
                        <div className={styles.frameChild8} />
                        <div className={styles.view6}>{`View `}</div>
                      </div>
                      <div className={styles.chezPierreRestaurant}>
                        Chez pierre restaurant in Monte Carlo by Vuidafieri
                      </div>
                      <div className={styles.business4}>BUSINESS</div>
                      <div className={styles.sep20226}>20 Sep 2022</div>
                      <div className={styles.storyChild1} />
                      <div className={styles.publishedWrapper2}>
                        <div className={styles.published5}>Published</div>
                      </div>
                      <div className={styles.icbaselineRemoveRedEyeGroup}>
                        <img
                          className={styles.icbaselineRemoveRedEyeIcon1}
                          alt=""
                          src="/icbaselineremoveredeye.svg"
                        />
                        <div className={styles.div3}>428</div>
                      </div>
                      <div className={styles.statusUpContainer}>
                        <img
                          className={styles.statusUpIcon1}
                          alt=""
                          src="/statusup-1.svg"
                        />
                      </div>
                    </div>
                    <div className={styles.story4}>
                      <img
                        className={styles.storyChild2}
                        alt=""
                        src="/rectangle-685-6@2x.png"
                      />
                      <div className={styles.rectangleParent5}>
                        <div className={styles.frameChild9} />
                        <div className={styles.view7}>{`View `}</div>
                      </div>
                      <div className={styles.teknionWinsGoldContainer}>
                        <p
                          className={styles.teknionWinsGold}
                        >{`Teknion wins Gold at 2022 `}</p>
                        <p className={styles.internationalDesignAwards}>
                          International Design Awards
                        </p>
                      </div>
                      <div className={styles.politics2}>Politics</div>
                      <div className={styles.sep20227}>20 Sep 2022</div>
                      <div className={styles.storyChild3} />
                      <div className={styles.publishedWrapper3}>
                        <div className={styles.published6}>Published</div>
                      </div>
                      <div className={styles.icbaselineRemoveRedEyeContainer}>
                        <img
                          className={styles.icbaselineRemoveRedEyeIcon2}
                          alt=""
                          src="/icbaselineremoveredeye.svg"
                        />
                        <div className={styles.div4}>428</div>
                      </div>
                      <div className={styles.statusUpFrame}>
                        <img
                          className={styles.statusUpIcon2}
                          alt=""
                          src="/statusup-1.svg"
                        />
                      </div>
                    </div>
                    <div className={styles.story5}>
                      <img
                        className={styles.storyChild4}
                        alt=""
                        src="/rectangle-685-4@2x.png"
                      />
                      <div className={styles.rectangleParent6}>
                        <div className={styles.frameChild10} />
                        <div className={styles.view8}>{`View `}</div>
                      </div>
                      <div className={styles.how7LinesContainer1}>
                        <p className={styles.how7Lines1}>
                          How 7 lines code turned into
                        </p>
                        <p className={styles.billionEmpire1}>
                          $36 Billion Empire
                        </p>
                      </div>
                      <div className={styles.business5}>BUSINESS</div>
                      <div className={styles.sep20228}>20 Sep 2022</div>
                      <div className={styles.storyChild5} />
                      <div className={styles.publishedWrapper4}>
                        <div className={styles.published7}>Published</div>
                      </div>
                      <div className={styles.icbaselineRemoveRedEyeParent1}>
                        <img
                          className={styles.icbaselineRemoveRedEyeIcon3}
                          alt=""
                          src="/icbaselineremoveredeye.svg"
                        />
                        <div className={styles.div5}>428</div>
                      </div>
                      <div className={styles.statusUpWrapper1}>
                        <img
                          className={styles.statusUpIcon3}
                          alt=""
                          src="/statusup-1.svg"
                        />
                      </div>
                    </div>
                    <Story visitFrameLanguage="/rectangle-685-8@2x.png" />
                    <div className={styles.story6}>
                      <img
                        className={styles.storyChild6}
                        alt=""
                        src="/rectangle-685-9@2x.png"
                      />
                      <div className={styles.iconEyeWrapper}>
                        <div className={styles.iconEye}>
                          <div className={styles.icbaselineRemoveRedEyeParent2}>
                            <img
                              className={styles.icbaselineRemoveRedEyeIcon4}
                              alt=""
                              src="/icbaselineremoveredeye.svg"
                            />
                            <div className={styles.div6}>428</div>
                          </div>
                          <div className={styles.statusUpWrapper2}>
                            <img
                              className={styles.statusUpIcon4}
                              alt=""
                              src="/statusup-1.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.frameParent5}>
                        <div
                          className={styles.chezPierreRestaurantInMontParent}
                        >
                          <h3 className={styles.chezPierreRestaurant1}>
                            Chez pierre restaurant in Monte Carlo by Vuidafieri
                          </h3>
                          <div className={styles.frameParent6}>
                            <div className={styles.businessWrapper}>
                              <div className={styles.business6}>BUSINESS</div>
                            </div>
                            <div className={styles.frameChild11} />
                            <div className={styles.separatorShape}>
                              <div className={styles.sep20229}>20 Sep 2022</div>
                            </div>
                            <button className={styles.createdWrapper}>
                              <div className={styles.created1}>Created</div>
                            </button>
                          </div>
                        </div>
                        <div className={styles.frameParent7}>
                          <button className={styles.rectangleParent7}>
                            <div className={styles.frameChild12} />
                            <div className={styles.view9}>{`View `}</div>
                          </button>
                          <button className={styles.language41}>
                            <img
                              className={styles.language4Item}
                              alt=""
                              src="/group-1000000956.svg"
                            />
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className={styles.story7}>
                      <img
                        className={styles.storyChild7}
                        alt=""
                        src="/rectangle-685-10@2x.png"
                      />
                      <div className={styles.iconEyeContainer}>
                        <div className={styles.iconEye1}>
                          <div className={styles.icbaselineRemoveRedEyeParent3}>
                            <img
                              className={styles.icbaselineRemoveRedEyeIcon5}
                              alt=""
                              src="/icbaselineremoveredeye.svg"
                            />
                            <div className={styles.div7}>428</div>
                          </div>
                          <div className={styles.statusUpWrapper3}>
                            <img
                              className={styles.statusUpIcon5}
                              alt=""
                              src="/statusup-1.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.frameParent8}>
                        <div className={styles.teknionWinsGoldAt2022InteParent}>
                          <h3 className={styles.teknionWinsGoldContainer1}>
                            <p
                              className={styles.teknionWinsGold1}
                            >{`Teknion wins Gold at 2022 `}</p>
                            <p className={styles.internationalDesignAwards1}>
                              International Design Awards
                            </p>
                          </h3>
                          <div className={styles.frameParent9}>
                            <div className={styles.frameWrapper1}>
                              <div className={styles.politicsParent}>
                                <div className={styles.politics3}>Politics</div>
                                <div className={styles.separatorLine1}>
                                  <div className={styles.ellipseShape} />
                                </div>
                                <div className={styles.sep202210}>
                                  20 Sep 2022
                                </div>
                              </div>
                            </div>
                            <button className={styles.draftWrapper}>
                              <div className={styles.draft}>Draft</div>
                            </button>
                          </div>
                        </div>
                        <div className={styles.frameParent10}>
                          <button className={styles.rectangleParent8}>
                            <div className={styles.frameChild13} />
                            <div className={styles.view10}>{`View `}</div>
                          </button>
                          <button className={styles.language42}>
                            <img
                              className={styles.language4Inner}
                              alt=""
                              src="/group-1000000956.svg"
                            />
                          </button>
                        </div>
                      </div>
                    </div>
                    <Story
                      visitFrameLanguage="/rectangle-685-11@2x.png"
                      propBackgroundColor="unset"
                      propBackgroundImage="url('/rectangle-685-11@2x.png')"
                      propBackgroundSize="cover"
                      propBackgroundRepeat="no-repeat"
                      propBackgroundPosition="top"
                    />
                  </div>
                  <div className={styles.story8}>
                    <img
                      className={styles.storyChild8}
                      alt=""
                      src="/rectangle-685-5@2x.png"
                    />
                    <div className={styles.storyInner1}>
                      <div className={styles.frameParent11}>
                        <div className={styles.icbaselineRemoveRedEyeParent4}>
                          <img
                            className={styles.icbaselineRemoveRedEyeIcon6}
                            alt=""
                            src="/icbaselineremoveredeye.svg"
                          />
                          <div className={styles.advertismentText}>428</div>
                        </div>
                        <div className={styles.statusUpWrapper4}>
                          <img
                            className={styles.statusUpIcon6}
                            alt=""
                            src="/statusup-1.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className={styles.chezPierreRestaurantParent}>
                      <div className={styles.chezPierreRestaurant2}>
                        <div className={styles.chezPierreRestaurantChild} />
                        <div className={styles.adTextFrame}>
                          <h3 className={styles.chezPierreRestaurant3}>
                            Chez pierre restaurant in Monte Carlo by Vuidafieri
                          </h3>
                          <div className={styles.businessContainer}>
                            <div className={styles.business7}>BUSINESS</div>
                          </div>
                          <div className={styles.publishedLabel}>
                            <div className={styles.separatorShape1}>
                              <div className={styles.sep202211}>
                                20 Sep 2022
                              </div>
                            </div>
                            <div className={styles.publishedWrapper5}>
                              <div className={styles.published8}>Published</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.textFrame}>
                        <div className={styles.textFrameChild} />
                        <div className={styles.view11}>{`View `}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
      <div className={styles.header}>
        <div className={styles.background} />
        <div className={styles.search1}>
          <div className={styles.iconlylightsearchParent}>
            <img
              className={styles.iconlylightsearch}
              alt=""
              src="/iconlylightsearch.svg"
            />
            <div className={styles.search2}>Search</div>
          </div>
        </div>
        <div className={styles.userProfile}>
          <div className={styles.hiAdminParent}>
            <div className={styles.hiAdmin}>
              <span>{`Hi, `}</span>
              <span className={styles.admin}>Admin</span>
            </div>
            <div className={styles.rectangleParent9}>
              <div className={styles.frameChild14} />
              <b className={styles.ad}>AD</b>
            </div>
          </div>
          <img
            className={styles.evaarrowDownFillIcon}
            alt=""
            src="/evaarrowdownfill.svg"
          />
        </div>
      </div>
      <FrameComponent />
    </div>
  );
};

export default ContentManagement;
