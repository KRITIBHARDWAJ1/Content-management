import { useMemo } from "react";
import styles from "./article.module.css";

const Article = ({
  da39df3511e5c0c30afdf26cf,
  libreCoffee,
  propHeight,
  propFlex,
  propGap,
  propHeight1,
  propHeight2,
  propFlex1,
}) => {
  const frameDiv1Style = useMemo(() => {
    return {
      height: propHeight,
    };
  }, [propHeight]);

  const frameDiv2Style = useMemo(() => {
    return {
      flex: propFlex,
      gap: propGap,
    };
  }, [propFlex, propGap]);

  const loremIpsumDolorStyle = useMemo(() => {
    return {
      height: propHeight1,
    };
  }, [propHeight1]);

  const frameDiv3Style = useMemo(() => {
    return {
      height: propHeight2,
      flex: propFlex1,
    };
  }, [propHeight2, propFlex1]);

  return (
    <div className={styles.article1}>
      <img
        className={styles.da39df3511e5c0c30afdf26cfef409Icon}
        alt=""
        src={da39df3511e5c0c30afdf26cf}
      />
      <div className={styles.article1Inner}>
        <div className={styles.libreCoffeeParent} style={frameDiv1Style}>
          <div className={styles.libreCoffee}>{libreCoffee}</div>
          <div
            className={styles.loremIpsumDolorSitAmetCoParent}
            style={frameDiv2Style}
          >
            <div
              className={styles.loremIpsumDolor}
              style={loremIpsumDolorStyle}
            >
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor
            </div>
            <div className={styles.frameParent} style={frameDiv3Style}>
              <div className={styles.rectangleParent}>
                <div className={styles.frameChild} />
                <div className={styles.visit}>Visit</div>
              </div>
              <div className={styles.language4}>
                <img
                  className={styles.language4Child}
                  alt=""
                  src="/group-1000000956.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Article;
