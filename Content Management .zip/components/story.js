import { useMemo } from "react";
import styles from "./story.module.css";

const Story = ({
  visitFrameLanguage,
  propBackgroundColor,
  propBackgroundImage,
  propBackgroundSize,
  propBackgroundRepeat,
  propBackgroundPosition,
}) => {
  const storyStyle = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
      backgroundImage: propBackgroundImage,
      backgroundSize: propBackgroundSize,
      backgroundRepeat: propBackgroundRepeat,
      backgroundPosition: propBackgroundPosition,
    };
  }, [
    propBackgroundColor,
    propBackgroundImage,
    propBackgroundSize,
    propBackgroundRepeat,
    propBackgroundPosition,
  ]);

  return (
    <div className={styles.story} style={storyStyle}>
      <img
        className={styles.visitFrameLanguage}
        alt=""
        src={visitFrameLanguage}
      />
      <div className={styles.iconEyeWrapper}>
        <div className={styles.iconEye}>
          <div className={styles.icbaselineRemoveRedEyeParent}>
            <img
              className={styles.icbaselineRemoveRedEyeIcon}
              alt=""
              src="/icbaselineremoveredeye.svg"
            />
            <div className={styles.div}>428</div>
          </div>
          <div className={styles.statusUpWrapper}>
            <img className={styles.statusUpIcon} alt="" src="/statusup-1.svg" />
          </div>
        </div>
      </div>
      <div className={styles.titleText}>
        <div className={styles.rectangle}>
          <h3 className={styles.how7LinesContainer}>
            <p className={styles.how7Lines}>How 7 lines code turned into</p>
            <p className={styles.billionEmpire}>$36 Billion Empire</p>
          </h3>
          <div className={styles.businessParent}>
            <div className={styles.business}>
              <div className={styles.business1}>BUSINESS</div>
            </div>
            <div className={styles.frameChild} />
            <div className={styles.separatorShape}>
              <div className={styles.sep2022}>20 Sep 2022</div>
            </div>
            <button className={styles.publishedCreated}>
              <div className={styles.published}>Published</div>
            </button>
          </div>
        </div>
        <div className={styles.group}>
          <button className={styles.rectangleParent}>
            <div className={styles.frameItem} />
            <div className={styles.view}>{`View `}</div>
          </button>
          <button className={styles.language4}>
            <img
              className={styles.language4Child}
              alt=""
              src="/group-1000000956.svg"
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Story;
