import { useMemo } from "react";
import styles from "./project.module.css";

const Project = ({
  projectIcon,
  articles,
  newUpdates,
  propColor,
  propColor1,
}) => {
  const articlesStyle = useMemo(() => {
    return {
      color: propColor,
    };
  }, [propColor]);

  const newUpdatesStyle = useMemo(() => {
    return {
      color: propColor1,
    };
  }, [propColor1]);

  return (
    <div className={styles.project}>
      <img
        className={styles.projectIcon}
        loading="eager"
        alt=""
        src={projectIcon}
      />
      <div className={styles.ellipseShape}>
        <h2 className={styles.articles} style={articlesStyle}>
          {articles}
        </h2>
        <div className={styles.newUpdates} style={newUpdatesStyle}>
          {newUpdates}
        </div>
      </div>
    </div>
  );
};

export default Project;
