import { useMemo } from "react";
import styles from "./article1.module.css";

const Article1 = ({
  textGroup,
  eCONOMY,
  researchOnBiodiversityAn,
  world,
  population,
  propPadding,
  propGap,
  propWidth,
  propWidth1,
}) => {
  const separatorLineStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const frameDivStyle = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  const visitLinkStyle = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const languageSelectionStyle = useMemo(() => {
    return {
      width: propWidth1,
    };
  }, [propWidth1]);

  return (
    <div className={styles.article2}>
      <div className={styles.shapeGroupParent}>
        <img
          className={styles.shapeGroupIcon}
          alt=""
          src="/rectangle-684@2x.png"
        />
        <img className={styles.textGroupIcon} alt="" src={textGroup} />
      </div>
      <div className={styles.frameParent}>
        <div className={styles.economyParent}>
          <div className={styles.economy}>{eCONOMY}</div>
          <div className={styles.separatorLine} style={separatorLineStyle}>
            <div className={styles.separatorLineChild} />
          </div>
          <div className={styles.sep2022}>20 Sep 2022</div>
        </div>
        <div className={styles.ellipseParent}>
          <img className={styles.frameChild} alt="" src="/ellipse-2@2x.png" />
          <div className={styles.mariaDoe}>Maria Doe</div>
        </div>
      </div>
      <div className={styles.frameGroup} style={frameDivStyle}>
        <div className={styles.researchOnBiodiversityAnParent}>
          <h3 className={styles.researchOnBiodiversity}>
            {researchOnBiodiversityAn}
          </h3>
          <div className={styles.loremIpsumDolor}>
            Lorem ipsum dolor sit amet, consectetur
          </div>
          <div className={styles.visitLink} style={visitLinkStyle}>
            <button
              className={styles.languageSelection}
              style={languageSelectionStyle}
            >
              <div className={styles.world}>{world}</div>
            </button>
            <button className={styles.populationWrapper}>
              <div className={styles.population}>{population}</div>
            </button>
          </div>
        </div>
        <button className={styles.publishedWrapper}>
          <div className={styles.published}>Published</div>
        </button>
      </div>
      <div className={styles.groupLanguageGroup}>
        <div className={styles.viewTextFrame}>
          <button className={styles.rectangleParent}>
            <div className={styles.frameItem} />
            <div className={styles.view}>{`View `}</div>
          </button>
          <div className={styles.language4}>
            <img
              className={styles.language4Child}
              alt=""
              src="/group-1000000956.svg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Article1;
