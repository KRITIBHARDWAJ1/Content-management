import styles from "./icon-frame.module.css";

const IconFrame = () => {
  return (
    <div className={styles.iconFrame}>
      <div className={styles.statusText}>
        <img className={styles.statusUpIcon} alt="" src="/statusup.svg" />
        <div className={styles.analytics}>Analytics</div>
        <div className={styles.wrapper}>
          <div className={styles.div}>3</div>
        </div>
      </div>
      <div className={styles.statusText1}>
        <input className={styles.videoSquare} type="checkbox" />
        <div className={styles.media}>Media</div>
        <div className={styles.container}>
          <div className={styles.div1}>16</div>
        </div>
      </div>
      <div className={styles.statusText2}>
        <img
          className={styles.notificationIcon}
          alt=""
          src="/notification.svg"
        />
        <div className={styles.notification}>Notification</div>
      </div>
      <div className={styles.statusText3}>
        <img
          className={styles.iconlylightsetting}
          alt=""
          src="/iconlylightsetting.svg"
        />
        <div className={styles.settings}>Settings</div>
      </div>
    </div>
  );
};

export default IconFrame;
