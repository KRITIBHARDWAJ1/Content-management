import Article from "./article";
import styles from "./frame-component.module.css";

const FrameComponent = () => {
  return (
    <div className={styles.contentManagementInner}>
      <div className={styles.frameAdvertisementsParent}>
        <div className={styles.frameAdvertisements}>
          <h3 className={styles.advertisment}>Advertisment</h3>
          <div className={styles.seeAll}>See all</div>
        </div>
        <div className={styles.latestAdvertisements}>
          <div className={styles.article1}>
            <img
              className={styles.da39df3511e5c0c30afdf26cfef409Icon}
              loading="eager"
              alt=""
              src="/da39df3511e5c0c30afdf26cfef40924-1@2x.png"
            />
            <div className={styles.group}>
              <div className={styles.libreCoffeeBrandParent}>
                <div className={styles.libreCoffeeBrand}>
                  <h3 className={styles.buildYourBusiness}>
                    Build your business
                  </h3>
                  <div className={styles.shopifyHasAll}>
                    Shopify has all the tools you need to start, sell, market,
                    and manage.
                  </div>
                </div>
                <div className={styles.text}>
                  <button className={styles.rectangleParent}>
                    <div className={styles.frameChild} />
                    <div className={styles.visit}>Visit</div>
                  </button>
                  <div className={styles.language4}>
                    <img
                      className={styles.language4Child}
                      alt=""
                      src="/group-1000000956.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Article
            da39df3511e5c0c30afdf26cf="/da39df3511e5c0c30afdf26cfef40924-1-1@2x.png"
            libreCoffee="Libre Coffee"
          />
          <Article
            da39df3511e5c0c30afdf26cf="/da39df3511e5c0c30afdf26cfef40924-1-2@2x.png"
            libreCoffee="KFC"
            propHeight="175px"
            propFlex="1"
            propGap="24px"
            propHeight1="50px"
            propHeight2="unset"
            propFlex1="1"
          />
        </div>
      </div>
    </div>
  );
};

export default FrameComponent;
